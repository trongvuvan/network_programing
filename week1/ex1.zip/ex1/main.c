#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "hazchem.h"

int main()
{
    execute();
    return 0;
}