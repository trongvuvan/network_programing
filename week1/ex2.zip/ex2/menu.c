#include<stdio.h>
#include "menu.h"

void menu(){
    printf("Learning Management System\n");
    printf("---------------------------------------------\n");
    printf("1.\t Add a new score broad\n");
    printf("2.\t Add score\n");
    printf("3.\t Remove score\n");
    printf("4.\t Search score\n");
    printf("5.\t Display score board and score report\n");
    printf("Your choice (1-6, other to quit): ");
}
